# LogoVerse — Your Brand. Your Universe.

A single-file, dark-themed AI logo studio: describe your brand, pick styles and colors, generate logo concepts, customize them live and export SVG/PNG.

**Status: demo build.** No image-generation provider is connected, so the studio creates original, editable *vector* concepts locally and shows the exact prompt a provider would receive. Nothing is faked as AI output.

## What works
- Landing page, Explore grid with filters, How It Works, Pricing, FAQ, footer
- 4-step studio: brand → style → colors → generate (prompt builder included)
- Results gallery (dark / light / transparent), detail dialog, favorites (saved in `localStorage` only)
- Customization studio: font, colors, layout, icon/text size, spacing, undo/reset
- Downloads: genuine SVG and PNG (fonts are referenced by name, not embedded)

## What is not built yet
- Real AI generation (needs a server-side route + provider API key — never put keys in `index.html`)
- Accounts / dashboard (planned: Supabase auth + row-level security)
- Payments and usage limits (pricing is illustrative)
- Privacy Policy, Terms, Contact pages

## Run locally
Open `index.html` in a browser. No build step. (Google Fonts need internet.)

## Deploy
**GitHub Pages:** Settings → Pages → Deploy from branch → `main` / root.
**Vercel:** Import the repo, Framework Preset = *Other*, no build command, output directory = `.`.

## Next steps
1. Migrate to Next.js (App Router) + TypeScript + Tailwind.
2. Add `/api/generate` with a provider abstraction; keep keys in env vars (`.env.example`).
3. Add Supabase auth + storage for private projects.
4. Write legal pages and confirm the provider's commercial-use terms.
